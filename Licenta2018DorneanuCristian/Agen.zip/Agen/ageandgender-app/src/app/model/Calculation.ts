export class Calculation {
  id: number;
  status: string;
  type: string;
  estimatedGender: string;
  estimatedAge: number;
  isFace: boolean;
  image: string;
  accessTokens: any[];
}
