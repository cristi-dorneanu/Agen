class CalculationResult:
    def __init__(self):
        self.calculationId = None
        self.estimatedAge = None
        self.image = None
        self.estimatedGender = None
        self.errorMessage = None
        self.calculationStatus = None
