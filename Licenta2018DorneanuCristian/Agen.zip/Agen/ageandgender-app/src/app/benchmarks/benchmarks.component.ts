import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-benchmarks',
  template: `
    <p>
      benchmarks works!
    </p>
  `,
  styles: []
})
export class BenchmarksComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
