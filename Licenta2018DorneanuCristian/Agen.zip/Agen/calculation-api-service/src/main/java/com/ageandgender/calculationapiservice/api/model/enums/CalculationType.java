package com.ageandgender.calculationapiservice.api.model.enums;

import java.io.Serializable;

public enum CalculationType implements Serializable {
    AGE_RECOGNITION,
    GENDER_RECOGNITION,
    FACE_VALIDATION
}
