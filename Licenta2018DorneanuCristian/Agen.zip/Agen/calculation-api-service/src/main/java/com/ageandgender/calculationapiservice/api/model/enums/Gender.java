package com.ageandgender.calculationapiservice.api.model.enums;

import java.io.Serializable;

public enum Gender implements Serializable {
    MALE,
    FEMALE;
}
